<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, WordPress Language, and ABSPATH. You can find more information
 * by visiting {@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'wp_medco');

/** MySQL database username */
define('DB_NAME', 'wp_medco');    // The name of the database
define('DB_USER', 'recwriter');     // Your MySQL username
define('DB_PASSWORD', 'fu11b10wnus3r'); // ...and password
define('DB_HOST', 'localhost');    // 99% chance you won't need to change this value
define('DB_CHARSET', 'utf8');
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '<^|Shu<,;|C/x=-;Ny+Z,cjxI{Fx%1lcgRt[|>gLyR<IZ :V+0d(<6x-ZQiY=OEl');
define('SECURE_AUTH_KEY',  '~|h_9*+$[]pI~8!&/)&Ggtxl7*&t0n?a3I<Oa*nYm9Gfa0=^Gzn7R_.+SGitdT[_');
define('LOGGED_IN_KEY',    '{Q/mmjkR.b8oE}wd{:+]2F9,WFvT bR/4UCtC{wV+nKwS=`~f+*gCU*{,|LQ,&Ds');
define('NONCE_KEY',        'E=O{//.C*DxW!6Kd8wU (>u/)|W4+mAEEljQGK[aBCL=2/v|)@v-A%MK FH{S 1[');
define('AUTH_SALT',        'n|7go$g?mdZ=k(D7DM3Paq+GT(2=<q1L)21Dt9n{OIzO--~;$/fUIZB-xG2=?+)k');
define('SECURE_AUTH_SALT', '~U*Bgrd<M_!)NXCVAgc6id:<wyH-#-M]H>r94~,&|S5ELir*/-*r-$]Q>4$LkWQc');
define('LOGGED_IN_SALT',   '+Oi0Z|MKe|yuFID_&P?*3[N4U#H:4AKj#R_wiA8Z(kgzih{m}/].:M89r3lT;w9X');
define('NONCE_SALT',       'Qfr;RC>CXM7U{;#r =k:B% |n>/5w2N@qf}]>r]prYsQH|%lw-`GFiKbhm;8Jssr');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * WordPress Localized Language, defaults to English.
 *
 * Change this to localize WordPress.  A corresponding MO file for the chosen
 * language must be installed to wp-content/languages. For example, install
 * de.mo to wp-content/languages and set WPLANG to 'de' to enable German
 * language support.
 */
define ('WPLANG', '');

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
